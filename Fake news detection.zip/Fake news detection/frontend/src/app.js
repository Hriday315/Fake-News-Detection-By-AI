import React, { useState } from "react";
import axios from "axios";

function App() {

  const [news, setNews] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const checkNews = async () => {

    if (!news) {
      alert("Enter some news!");
      return;
    }

    setLoading(true);

    try {
      const res = await axios.post("http://localhost:5000/analyze", {
        news: news
      });

      setResult(res.data.result);

    } catch (err) {
      alert("Error connecting to server");
      console.log(err);
    }

    setLoading(false);
  };

  return (
    <div style={styles.container}>

      <h1>📰 Fake News Detector</h1>

      <textarea
        placeholder="Paste news here..."
        value={news}
        onChange={(e) => setNews(e.target.value)}
        style={styles.textarea}
      />

      <button onClick={checkNews} style={styles.button}>
        {loading ? "Checking..." : "Check News"}
      </button>

      {result && (
        <div style={styles.result}>
          <h3>Result:</h3>
          <p>{result}</p>
        </div>
      )}

    </div>
  );
}

const styles = {
  container: {
    width: "60%",
    margin: "auto",
    marginTop: "50px",
    textAlign: "center",
    fontFamily: "Arial"
  },

  textarea: {
    width: "100%",
    height: "150px",
    padding: "10px",
    fontSize: "16px"
  },

  button: {
    marginTop: "20px",
    padding: "10px 20px",
    fontSize: "18px",
    cursor: "pointer"
  },

  result: {
    marginTop: "30px",
    padding: "20px",
    backgroundColor: "#f2f2f2",
    borderRadius: "5px"
  }
};

export default App;