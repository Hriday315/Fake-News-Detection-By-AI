from flask import Flask, request, jsonify
from flask_cors import CORS
import openai
import os

# Load your OpenAI key
openai.api_key = "YOUR_OPENAI_API_KEY"

app = Flask(__name__)
CORS(app)


@app.route("/analyze", methods=["POST"])
def analyze_news():

    data = request.json
    news = data.get("news")

    if not news:
        return jsonify({"error": "No news provided"}), 400

    prompt = f"""
    Analyze the following news and tell if it is FAKE or REAL.
    Also explain briefly.

    News:
    {news}
    """

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a fact-checking assistant."},
                {"role": "user", "content": prompt}
            ]
        )

        result = response["choices"][0]["message"]["content"]

        return jsonify({"result": result})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True)